Possible future changes
-----------------------

* version all gems in Gemfile
* clean rails new
* rails 5?
* associated tests
* remove time stamp format to be just a date
* adjusting position of root in routes.rb?
* replace mechanize with rspec? and include in boiler plate rspec in initial repo?
